import React, { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileDown, Filter, ChevronLeft, ChevronRight, Loader2, X } from "lucide-react";
import { formatPesoCurrency } from "@/lib/formatters";
import { useToast } from "@/hooks/use-toast";
import axios from "axios";
import { DateRange } from "react-day-picker";
import { format, isWithinInterval, startOfDay, endOfDay } from "date-fns";
import { DateRangePicker } from "@/components/DateRangePicker";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface Transaction {
  id: number;
  amount: string;
  currency: string;
  refId: string;
  invoiceNo: string;
  txnDesc: string;
  txnDate: number;
  txnId: number;
  status: string;
  created_at: string;
  merchant_id: string;
  merchant_username: string | null;
}

interface PaginationData {
  current_page: string | number;
  total_pages: number;
  total_records: number;
  limit: string | number;
}

interface ApiResponse {
  status: string;
  pagination: PaginationData;
  data: Transaction[];
}

const API_BASE_URL = "https://direct-payph.com/api/report";

const Reports = () => {
  const { toast } = useToast();
  const [isExporting, setIsExporting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [pagination, setPagination] = useState<PaginationData>({
    current_page: 1,
    total_pages: 1,
    total_records: 0,
    limit: 10
  });
  const [error, setError] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);
  const [isFilterDialogOpen, setIsFilterDialogOpen] = useState(false);

  const fetchTransactions = async (page: number = 1, limit: number = 10) => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Get the auth token from sessionStorage
      const token = sessionStorage.getItem("data");
      
      // If no token is available, show an error
      if (!token) {
        throw new Error("Authentication token not found. Please log in again.");
      }
      
      const response = await axios.get<ApiResponse>(`${API_BASE_URL}/${page}/${limit}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      if (response.data.status === "success") {
        setTransactions(response.data.data);
        setFilteredTransactions(response.data.data);
        setPagination(response.data.pagination);
        applyDateFilter(response.data.data);
      } else {
        throw new Error("Failed to fetch transaction data");
      }
    } catch (err) {
      console.error("Error fetching transactions:", err);
      
      let errorMessage = "Failed to load transaction data. Please try again later.";
      
      // Check for authentication errors specifically
      if (err.response && (err.response.status === 401 || err.response.status === 403)) {
        errorMessage = "Your session has expired. Please log in again.";
      }
      
      setError(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions(Number(pagination.current_page), Number(pagination.limit));
  }, []);

  // Apply date filter whenever date range changes
  useEffect(() => {
    applyDateFilter(transactions);
  }, [dateRange, transactions]);

  const applyDateFilter = (txns: Transaction[]) => {
    if (!dateRange || !dateRange.from) {
      setFilteredTransactions(txns);
      return;
    }

    const filteredTxns = txns.filter(transaction => {
      const txnDate = new Date(transaction.txnDate > 9999999999 ? transaction.txnDate : transaction.txnDate * 1000);
      
      if (dateRange.from && !dateRange.to) {
        // If only "from" date is selected, show transactions from that date onwards
        return txnDate >= startOfDay(dateRange.from);
      } else if (dateRange.from && dateRange.to) {
        // If both dates are selected, show transactions within that range
        return isWithinInterval(txnDate, {
          start: startOfDay(dateRange.from),
          end: endOfDay(dateRange.to || dateRange.from)
        });
      }
      return true;
    });

    setFilteredTransactions(filteredTxns);
  };

  const handleDateRangeChange = (range: DateRange | undefined) => {
    setDateRange(range);
    if (!range || !range.from) {
      toast({
        title: "Filter cleared",
        description: "Showing all transactions"
      });
    } else {
      const description = range.to 
        ? `Showing transactions from ${format(range.from, 'MMM dd, yyyy')} to ${format(range.to, 'MMM dd, yyyy')}`
        : `Showing transactions from ${format(range.from, 'MMM dd, yyyy')}`;
      
      toast({
        title: "Date filter applied",
        description
      });
    }
    setIsFilterDialogOpen(false);
  };

  const clearDateFilter = () => {
    setDateRange(undefined);
    setFilteredTransactions(transactions);
    toast({
      title: "Filter cleared",
      description: "Showing all transactions"
    });
  };

  const formatDate = (timestamp: number): string => {
    // Check if timestamp is in milliseconds (13 digits) or seconds (10 digits)
    const date = new Date(timestamp > 9999999999 ? timestamp : timestamp * 1000);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const exportToExcel = () => {
    setIsExporting(true);
    
    try {
      // Create CSV content using filtered transactions
      const headers = ["Date", "Invoice No", "Reference ID", "Transaction ID", "Description", "Amount", "Status", "Merchant"];
      const csvContent = [
        headers.join(","),
        ...filteredTransactions.map(transaction => [
          new Date(transaction.txnDate > 9999999999 ? transaction.txnDate : transaction.txnDate * 1000).toISOString().split('T')[0],
          transaction.invoiceNo,
          transaction.refId,
          transaction.txnId,
          transaction.txnDesc,
          `${transaction.amount} ${transaction.currency}`,
          transaction.status,
          transaction.merchant_username || "N/A"
        ].join(","))
      ].join("\n");
      
      // Create a blob and download link
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      
      // Set up download
      link.setAttribute("href", url);
      const fileName = dateRange?.from 
        ? `transaction_report_${format(dateRange.from, 'yyyy-MM-dd')}_to_${dateRange.to ? format(dateRange.to, 'yyyy-MM-dd') : 'present'}.csv`
        : `transaction_report_${new Date().toISOString().split('T')[0]}.csv`;
      
      link.setAttribute("download", fileName);
      document.body.appendChild(link);
      
      // Trigger download and cleanup
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Report exported successfully",
        description: "Your transaction report has been downloaded as a CSV file.",
      });
    } catch (error) {
      console.error("Export failed:", error);
      toast({
        title: "Export failed",
        description: "There was an error exporting your report. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const getStatusClass = (status: string) => {
    switch (status.toUpperCase()) {
      case "SUCCESS":
      case "COMPLETED":
        return "bg-green-100 text-green-800 border-green-200";
      case "FAILED":
        return "bg-red-100 text-red-800 border-red-200";
      case "PENDING":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const handleNextPage = () => {
    const currentPage = Number(pagination.current_page);
    if (currentPage < pagination.total_pages) {
      fetchTransactions(currentPage + 1, Number(pagination.limit));
    }
  };

  const handlePrevPage = () => {
    const currentPage = Number(pagination.current_page);
    if (currentPage > 1) {
      fetchTransactions(currentPage - 1, Number(pagination.limit));
    }
  };

  const hasActiveFilter = dateRange && dateRange.from;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Transaction Reports</h1>
            <p className="text-muted-foreground">
              View and export transaction data for your records
            </p>
          </div>
          <Button 
            onClick={exportToExcel} 
            className="w-full md:w-auto" 
            disabled={isExporting || isLoading || filteredTransactions.length === 0}
          >
            {isExporting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileDown className="mr-2 h-4 w-4" />}
            {isExporting ? "Exporting..." : "Export to CSV"}
          </Button>
        </div>

        <Card>
          <CardHeader>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <CardTitle>Transaction History</CardTitle>
                <CardDescription>
                  A complete record of all transactions
                  {hasActiveFilter && dateRange.from && (
                    <span className="ml-2">
                      (Filtered: {format(dateRange.from, 'MMM dd, yyyy')}
                      {dateRange.to && ` - ${format(dateRange.to, 'MMM dd, yyyy')}`})
                    </span>
                  )}
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                {hasActiveFilter && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={clearDateFilter}
                    className="h-9"
                  >
                    <X className="mr-2 h-4 w-4" />
                    Clear Filter
                  </Button>
                )}
                <Dialog open={isFilterDialogOpen} onOpenChange={setIsFilterDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Filter className="mr-2 h-4 w-4" />
                      Filter by Date
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Filter Transactions by Date</DialogTitle>
                    </DialogHeader>
                    <div className="py-4">
                      <DateRangePicker 
                        dateRange={dateRange} 
                        onDateRangeChange={handleDateRangeChange}
                        className="w-full"
                      />
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setIsFilterDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={() => handleDateRangeChange(dateRange)}>
                        Apply Filter
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center items-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <span className="ml-2 text-muted-foreground">Loading transactions...</span>
              </div>
            ) : error ? (
              <div className="py-8 text-center text-red-500">
                {error}
              </div>
            ) : filteredTransactions.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground">
                {transactions.length === 0 ? "No transactions found." : "No transactions match the applied filters."}
              </div>
            ) : (
              <div className="rounded-md border overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-muted/50">
                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Date</th>
                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Invoice No</th>
                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Reference ID</th>
                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Description</th>
                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Amount</th>
                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Status</th>
                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Merchant</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredTransactions.map((transaction) => (
                        <tr key={transaction.id} className="border-t hover:bg-muted/50">
                          <td className="p-4 align-middle">{formatDate(transaction.txnDate)}</td>
                          <td className="p-4 align-middle font-medium">{transaction.invoiceNo}</td>
                          <td className="p-4 align-middle">{transaction.refId}</td>
                          <td className="p-4 align-middle">{transaction.txnDesc}</td>
                          <td className="p-4 align-middle">{formatPesoCurrency(parseFloat(transaction.amount))}</td>
                          <td className="p-4 align-middle">
                            <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold ${getStatusClass(transaction.status)}`}>
                              {transaction.status}
                            </span>
                          </td>
                          <td className="p-4 align-middle">{transaction.merchant_username || "N/A"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            
            {/* Pagination controls */}
            {!isLoading && !error && transactions.length > 0 && (
              <div className="flex items-center justify-between mt-4">
                <div className="text-sm text-muted-foreground">
                  Showing page {pagination.current_page} of {pagination.total_pages} 
                  ({filteredTransactions.length} of {pagination.total_records} records)
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handlePrevPage}
                    disabled={Number(pagination.current_page) <= 1}
                  >
                    <ChevronLeft className="h-4 w-4" />
                    Previous
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleNextPage}
                    disabled={Number(pagination.current_page) >= pagination.total_pages}
                  >
                    Next
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default Reports;
