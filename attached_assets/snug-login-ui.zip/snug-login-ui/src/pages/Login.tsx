
import { useState, useEffect, useCallback } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { ArrowRight, Check, LockKeyhole, Mail } from "lucide-react";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [csrfToken, setCsrfToken] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  // Function to fetch CSRF token
  const fetchCsrfToken = useCallback(async () => {
    try {
      console.log("Fetching CSRF token...");
      const response = await axios.get("https://direct-payph.com/api/csrf_token", { withCredentials: true });
      sessionStorage.setItem("csrf_token", response.data.csrf_token);
      setCsrfToken(response.data.csrf_token);
      console.log("CSRF token fetched successfully");
      return response.data.csrf_token;
    } catch (error) {
      console.error("Error fetching CSRF token:", error);
      toast({
        title: "Error fetching CSRF token",
        description: "Please try again later",
        variant: "destructive",
      });
      return null;
    }
  }, [toast]);

  // Fetch CSRF token on component mount
  useEffect(() => {
    fetchCsrfToken();
  }, [fetchCsrfToken]);

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!username || !password) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    // Get the latest token from state or session storage
    let tokenToUse = csrfToken || sessionStorage.getItem("csrf_token");
    
    try {
      const response = await axios.post(
        "https://direct-payph.com/api/create/login",
        { username, password },
        {
          headers: {
            "X-CSRF-Token": tokenToUse,
          },
          withCredentials: true,
        }
      );
      
      setIsLoading(false);
      if (response.data.status === "success") {
        const token = response.data.data.token; // Get token only
        
        sessionStorage.setItem("loggedIn", "true");
        sessionStorage.setItem("userData", JSON.stringify(response.data.data.username));
        sessionStorage.setItem("data", token);
 
        toast({
          title: "Welcome back!",
          description: "You have successfully logged in",
        });
        
        // Force a re-evaluation of the auth state before navigation
        setTimeout(() => {
          navigate("/dashboard", { replace: true });
        }, 100);
      } else {
        setError(response.data.message);
        toast({
          title: "Login Failed",
          description: response.data.message || "Invalid credentials",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Login error:", error);
      
      // Handle 403 Forbidden - Invalid CSRF Token
      if (error.response && error.response.status === 403) {
        console.log("Detected 403 Forbidden - Invalid CSRF Token, refreshing page");
        toast({
          title: "Session expired",
          description: "Refreshing your session...",
        });
        
        // Store attempted login credentials temporarily in sessionStorage
        sessionStorage.setItem("login_attempt_username", username);
        sessionStorage.setItem("login_attempt_password", password);
        
        // Refresh the entire page instead of just retrying the request
        setTimeout(() => {
          window.location.reload();
        }, 1000);
        return;
      }
      
      setIsLoading(false);
      setError("Login failed. Please try again.");
      toast({
        title: "Login Failed",
        description: error.response?.data?.message || "An error occurred during login",
        variant: "destructive",
      });
    }
  };

  // Check for stored login attempt on page load
  useEffect(() => {
    const storedUsername = sessionStorage.getItem("login_attempt_username");
    const storedPassword = sessionStorage.getItem("login_attempt_password");
    
    if (storedUsername && storedPassword) {
      // Set the stored credentials
      setUsername(storedUsername);
      setPassword(storedPassword);
      
      // Clear the stored credentials
      sessionStorage.removeItem("login_attempt_username");
      sessionStorage.removeItem("login_attempt_password");
      
      // Auto-submit the form after a short delay to allow CSRF token to be fetched
      const timer = setTimeout(() => {
        const event = { preventDefault: () => {} };
        handleSubmit(event);
      }, 1500);
      
      return () => clearTimeout(timer);
    }
  }, [csrfToken]); // Depend on csrfToken to ensure it's available

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-blue-50 to-white px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md space-y-8 animate-enter">
        <div className="text-center">
          <div className="mx-auto h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <LockKeyhole className="h-6 w-6 text-primary" />
          </div>
          <h2 className="mt-6 text-3xl font-bold tracking-tight">Direct Pay</h2>
          <p className="mt-2 text-sm text-muted-foreground">Sign in to your account to continue</p>
        </div>

        <Card className="shadow-subtle backdrop-blur-sm bg-white/80 border-border/50">
          <CardHeader className="space-y-1 pb-4">
            <CardTitle className="text-xl">Sign in</CardTitle>
            <CardDescription>Account Code</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="username"
                    placeholder="Username"
                    type="text"
                    autoCapitalize="none"
                    autoComplete="email"
                    autoCorrect="off"
                    disabled={isLoading}
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center">
                  <Label htmlFor="password">Password</Label>
                </div>
                <div className="relative">
                  <LockKeyhole className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    disabled={isLoading}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-muted-foreground text-sm"
                  >
                    {showPassword ? "Hide" : "Show"}
                  </button>
                </div>
              </div>
              <Button type="submit" className="w-full flex items-center gap-2 group rounded-xl" disabled={isLoading}>
                <span>Sign In</span>
                <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform duration-200" />
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <div className="text-center text-sm">
              <span className="text-muted-foreground">Don't have an account?</span>{" "}
              <Link
                to="#"
                className="underline text-primary hover:text-primary/80"
                onClick={(e) => {
                  e.preventDefault();
                  toast({
                    title: "Sign-Up Information",
                    description: "Please contact admin@admin.com to create an account.",
                  });
                }}
              >
                Sign up
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
