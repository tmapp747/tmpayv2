import { ProfileCard } from "@/components/ProfileCard";
import { StatCard } from "@/components/StatCard";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowUpRight, BarChart3, DollarSign, Eye, Users, Wallet } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { useState, useEffect, useRef } from "react";
import { AddUserForm } from "@/components/users/AddUserForm";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useToast } from "@/hooks/use-toast";
import { formatPesoCurrency } from "@/lib/formatters";

const initialRevenueData = [
  { name: "Jan", value: 0 },
  { name: "Feb", value: 0 },
  { name: "Mar", value: 0 },
  { name: "Apr", value: 0 },
  { name: "May", value: 0 },
  { name: "Jun", value: 0 },
  { name: "Jul", value: 0 },
  { name: "Aug", value: 0 },
  { name: "Sep", value: 0 },
  { name: "Oct", value: 0 },
  { name: "Nov", value: 0 },
  { name: "Dec", value: 0 },
];

const activities = [
  {
    id: 1,
    user: "John Doe",
    action: "Created a new project",
    time: "2 hours ago",
  },
  {
    id: 2,
    user: "Sarah Johnson",
    action: "Updated client information",
    time: "5 hours ago",
  },
  {
    id: 3,
    user: "Mike Wilson",
    action: "Completed monthly report",
    time: "Yesterday",
  },
  {
    id: 4,
    user: "Emily Brown",
    action: "Added new user",
    time: "Yesterday",
  },
];

export default function Dashboard() {
  const [addUserOpen, setAddUserOpen] = useState(false);
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userInfo, setUserInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [totalAmount, setTotalAmount] = useState("0");
  const [WalletBalance, setWalletBalance] = useState("0");
  const [totalAmount_Failed, setTotalAmount_Failed] = useState("0");
  const [revenueData, setRevenueData] = useState(initialRevenueData.map(item => ({
    ...item,
    successful: 0,
    failed: 0
  })));

  const { toast } = useToast();
  const pollingIntervalRef = useRef(null);
  
  const userData = JSON.parse(sessionStorage.getItem("userData"));
  const token = sessionStorage.getItem("data");
 
  useEffect(() => {
    const loggedIn = sessionStorage.getItem("loggedIn");
    if (!loggedIn) {
      navigate("/login");
    }
  }, [navigate]);

  useEffect(() => {
    if (token) {
      fetchUserInfo();
      fetchRevenueData();
      
      setWalletBalance(formatPesoCurrency(25000));
      
      pollingIntervalRef.current = setInterval(() => {
        fetchUserInfo(false);
      }, 30000);
      
      return () => {
        if (pollingIntervalRef.current) {
          clearInterval(pollingIntervalRef.current);
        }
      };
    }
  }, [token]);

  const decodeBase64 = (encoded) => {
    if (!encoded) return "No email available";
    
    try {
      // Check if the string is valid base64
      if (!/^[A-Za-z0-9+/=]+$/.test(encoded)) {
        console.log("Invalid Base64 string format");
        return "Invalid email format";
      }
      
      // Try to decode
      return atob(encoded);
    } catch (error) {
      console.error("Error decoding Base64 string:", error);
      return "Error decoding email";
    }
  };
  
  const handleUnauthorized = () => {
    sessionStorage.removeItem("loggedIn");
    sessionStorage.removeItem("userData");
    sessionStorage.removeItem("data");
    
    toast({
      title: "Session Expired",
      description: "Your session has expired. Please log in again.",
      variant: "destructive",
    });
    
    navigate("/login");
  };
  
  const formatPesoCurrency = (amount) => {
    return new Intl.NumberFormat("en-PH", {
      style: "currency",
      currency: "PHP",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  };
  
  const fetchRevenueData = async () => {
    if (!token) return;

    try {
      // Fetch successful transactions
      const successResponse = await axios.get('https://direct-payph.com/api/user/infograp', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      // Fetch failed transactions
      const failedResponse = await axios.get('https://direct-payph.com/api/user/infograpfail', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      // console.log("Successful revenue data:", successResponse.data);
      // console.log("Failed revenue data:", failedResponse.data);
      
      if (successResponse.data && Array.isArray(successResponse.data) && 
          failedResponse.data && Array.isArray(failedResponse.data)) {
        
        // Combine both datasets
        const formattedData = successResponse.data.map((item, index) => {
          const failedItem = failedResponse.data[index] || { value: "0.00" };
          
          return {
            name: item.name,
            value: parseFloat(item.value),
            successful: parseFloat(item.value),
            failed: parseFloat(failedItem.value)
          };
        });
        
        setRevenueData(formattedData);
      }
    } catch (error) {
      console.error("Error fetching revenue data:", error);
      
      if (error.response && error.response.status === 401) {
        handleUnauthorized();
      } else {
        toast({
          title: "Error",
          description: "Failed to fetch revenue data",
          variant: "destructive",
        });
      }
    }
  };
  
  const fetchUserInfo = async (showLoading = true) => {
    if (showLoading) {
      setLoading(true);
    }
    
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'https://direct-payph.com/api/user/info',
      headers: { 
        'Authorization': `Bearer ${token}`, 
      }
    };

    try {
      const response = await axios.request(config);
      // console.log("User info response:", JSON.stringify(response.data));
      
      if (response.data && response.data.error && response.data.error.includes("401 Unauthorized")) {
        handleUnauthorized();
        return;
      }
      
      setUserInfo(response.data);

      const newwallet_funds = response.data.data.wallet_funds;
      const formattedAmountwallet_funds = formatPesoCurrency(newwallet_funds);
      setWalletBalance(formattedAmountwallet_funds);
   
      
      if (response.data?.data?.total_amount || response.data?.data?.total_amount_failed) {
        const newTotalAmount = response.data.data.total_amount;
        const newTotalAmount_Failed = response.data.data.total_amount_failed;
        
        
        if (newTotalAmount !== totalAmount || newTotalAmount_Failed !== totalAmount_Failed) {
          const formattedAmount = formatPesoCurrency(newTotalAmount);
          const formattedAmount2 = formatPesoCurrency(newTotalAmount_Failed);

         
          setTotalAmount(formattedAmount);
          setTotalAmount_Failed(formattedAmount2);
        

      
          if ((totalAmount !== "₱0.00" && !showLoading) || (totalAmount_Failed !== "₱0.00" && !showLoading)) {
            toast({
              title: "Total Incoming Updated",
              description: `Deposite has been updated to ${formattedAmount} \n Failed Transaction Amount to ${formattedAmount2}`,
              variant: "default",
            });
          }
        }
      }
      
      if (showLoading) {
        setLoading(false);
      }
    } catch (error) {
      console.error("Error fetching user info:", error);
      
      if (error.response && error.response.status === 401) {
        handleUnauthorized();
      } else {
        toast({
          title: "Error",
          description: "Failed to fetch user information",
          variant: "destructive",
        });
      }
      
      if (showLoading) {
        setLoading(false);
      }
    }
  };

  const userEmail = userInfo?.data?.email ? decodeBase64(userInfo.data.email) : "No email available";
  const displayName = userInfo?.data?.username || userData?.username || "User";
  const displayfname = userInfo?.data?.fname || userData?.fname || "No data record";
  const displaylname = userInfo?.data?.lname || userData?.lname || "No data record";
  const displayluseraddress = userInfo?.data?.address || userData?.address || "No data record";
  const displaylcontact_number = userInfo?.data?.contact_number || userData?.contact_number || "No data record";

  return (
    <DashboardLayout>
      <h1 className="text-2xl font-bold tracking-tight mb-6">Dashboard Overview</h1>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <StatCard
          title="Successful Transaction"
          value={loading ? "Loading..." : `${totalAmount}`}
          icon={<span className="text-xl font-bold">₱</span>}
          variant="success"
        />
        <StatCard
          title="Failed Transaction"
          value={loading ? "Loading..." : `${totalAmount_Failed}`}
          icon={<span className="text-xl font-bold">₱</span>}
          variant="error"
        />

        <StatCard
          title="Conversion Rate"
          value="3.2%"
          icon={<BarChart3 className="h-5 w-5" />}
          trend={{ value: 1.5, isPositive: true }}
          variant="warning"
        />

        <StatCard
          title="Wallet Balance"
          value={loading ? "Loading..." : `${WalletBalance}`}
          icon={<span className="text-xl font-bold">₱</span>}
          variant="primary"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
        <div className="lg:col-span-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between p-6 pb-0">
              <div>
                <CardTitle>Analytics</CardTitle>
                <CardDescription>Revenue data analytics</CardDescription>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={revenueData}
                    margin={{
                      top: 5,
                      right: 10,
                      left: 10,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.2} />
                    <XAxis dataKey="name" />
                    <YAxis 
                      tickFormatter={(value) => 
                        value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value
                      } 
                    />
                    <Tooltip 
                      formatter={(value, name) => {
                        if (name === "successful") return [formatPesoCurrency(value), "Successful Transactions"];
                        if (name === "failed") return [formatPesoCurrency(value), "Failed Transactions"];
                        return [formatPesoCurrency(value), name];
                      }}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      name="Successful Transactions"
                      dataKey="successful"
                      stroke="#10b981"
                      strokeWidth={2}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                    <Line
                      type="monotone"
                      name="Failed Transactions"
                      dataKey="failed"
                      stroke="#ef4444"
                      strokeWidth={2}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <ProfileCard
            user={{
              username: displayName,
              fname: displayfname,
              lname: displaylname,
              displayluseraddress: displayluseraddress,
              displaylcontact_number: displaylcontact_number,
              email: userEmail,
            }}
            className="h-full"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Activities</CardTitle>
            <CardDescription>
              Your team's activity in the last 24 hours
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {activities.map((activity) => (
                <div key={activity.id} className="flex items-start gap-4">
                  <div className="rounded-full bg-primary/10 p-2">
                    <Users className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium">{activity.user}</p>
                    
                    <p className="text-xs text-muted-foreground">
                      {activity.action}
                    </p>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {activity.time}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>
              Frequently used actions and shortcuts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <Button 
                variant="outline" 
                className="h-24 flex-col gap-2 hover:border-primary hover:bg-primary/5"
                onClick={() => setAddUserOpen(true)}
              >
                <Users className="h-6 w-6" />
                <span>Add User</span>
              </Button>
              <Button variant="outline" className="h-24 flex-col gap-2 hover:border-primary hover:bg-primary/5">
                <BarChart3 className="h-6 w-6" />
                <span>New Report</span>
              </Button>
              <Button variant="outline" className="h-24 flex-col gap-2 hover:border-primary hover:bg-primary/5">
                <DollarSign className="h-6 w-6" />
                <span>Invoices</span>
              </Button>
              <Button variant="outline" className="h-24 flex-col gap-2 hover:border-primary hover:bg-primary/5">
                <ArrowUpRight className="h-6 w-6" />
                <span>Exports</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <AddUserForm open={addUserOpen} onOpenChange={setAddUserOpen} />
    </DashboardLayout>
  );
}

