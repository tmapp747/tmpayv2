
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Bell, Settings } from "lucide-react";

interface ProfileCardProps extends React.HTMLAttributes<HTMLDivElement> {
  user: {
    name?: string;
    username?: string;
    email: string;
    avatar?: string;
    fname?: string;
    lname?: string;
    displayluseraddress?: string;
    displaylcontact_number?: string;
  };
}

export function ProfileCard({ user, className, ...props }: ProfileCardProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center p-6 bg-white rounded-xl shadow-subtle animate-enter",
        className
      )}
      {...props}
    >
      <div className="relative">
        <Avatar className="h-20 w-20 shadow-subtle">
          <AvatarImage src={user.avatar} alt={user.username} />
          <AvatarFallback className="text-lg bg-primary/10 text-primary">
            {user.username
              ? user.username.split(" ")[0][0]
              : user.name
                ? user.name.split(" ")[0][0]
                : "U"}
          </AvatarFallback>
        </Avatar>
        <span className="absolute bottom-0 right-0 h-4 w-4 rounded-full bg-green-500 border-2 border-white" />
      </div>
      
      <div className="mt-4 text-center">
        <h3 className="font-semibold text-lg">{user.username}</h3>
        <p className="text-sm text-muted-foreground">{user.email}</p>
      </div>
      
      <div className="flex gap-2 mt-6 w-full">
        <Button variant="outline" size="sm" className="flex-1 rounded-lg">
          <Settings className="mr-2 h-4 w-4" />
          Settings
        </Button>
      </div>

      <div className="mt-4 text-center">
        <h3 className="font-semibold text-lg">{user.fname} {user.lname}</h3>
        <p className="text-sm text-muted-foreground">{user.displayluseraddress}</p>
        <p className="text-sm text-muted-foreground">{user.displaylcontact_number}</p>
        
      </div>
    </div>
  );
}
