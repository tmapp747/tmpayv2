import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import {
  BarChart3,
  FileText,
  Home,
  LayoutDashboard,
  LogOut,
  MessagesSquare,
  Settings,
  Users
} from "lucide-react";
import { ReactNode, useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Navbar } from "../Navbar";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";

interface DashboardLayoutProps {
  children: ReactNode;
}

interface NavItemProps {
  icon: ReactNode;
  label: string;
  href: string;
  isActive?: boolean;
  onClick?: () => void;
}

function NavItem({ icon, label, href, isActive, onClick }: NavItemProps) {
  return (
    <Link
      to={href}
      className={cn(
        "flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
        isActive
          ? "bg-primary/10 text-primary font-medium"
          : "text-muted-foreground hover:bg-secondary hover:text-foreground"
      )}
      onClick={onClick}
    >
      {icon}
      <span>{label}</span>
    </Link>
  );
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const isMobile = useIsMobile();
  const [isSidebarOpen, setIsSidebarOpen] = useState(!isMobile);
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    setIsSidebarOpen(!isMobile);
  }, [isMobile]);

  const handleLogout = () => {
    toast({
      title: "Logged out successfully",
      description: "You have been logged out of your account",
    });
    navigate("/login");
  };

  const closeSidebarOnMobile = () => {
    if (isMobile) {
      setIsSidebarOpen(false);
    }
  };

  const navItems = [
    {
      icon: <Home className="h-4 w-4" />,
      label: "Home",
      href: "/dashboard",
      id: "home"
    },
    {
      icon: <LayoutDashboard className="h-4 w-4" />,
      label: "Dashboard",
      href: "/dashboard/main",
      id: "dashboard"
    },
    {
      icon: <FileText className="h-4 w-4" />,
      label: "Reports",
      href: "/reports",
      id: "reports"
    },
  ];

  return (
    <div className="min-h-screen flex bg-muted/30 antialiased">
      {isMobile && isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-10"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
      
      <aside
        className={cn(
          "fixed inset-y-0 z-20 flex flex-col bg-background border-r shadow-sm transition-all duration-300 ease-in-out",
          isSidebarOpen ? "w-64 translate-x-0" : "w-[70px] -translate-x-full md:translate-x-0",
          "md:relative"
        )}
      >
        <div className="flex h-16 items-center border-b px-4">
          <div className="flex items-center gap-2">
            <div
              className={cn(
                "flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold"
              )}
            >
              DP
            </div>
            <span
              className={cn(
                "text-lg font-semibold transition-opacity duration-200",
                (!isSidebarOpen || (isMobile && !isSidebarOpen)) && "opacity-0"
              )}
            >
              Dirct Pay
            </span>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-3 h-10 w-10 rounded-full md:flex hidden"
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className={cn("transition-transform duration-200", isSidebarOpen ? "rotate-0" : "rotate-180")}
            >
              <path d="m15 6-6 6 6 6" />
            </svg>
          </Button>
        </div>

        <div className="flex-1 overflow-auto py-2 px-3">
          <div className="flex flex-col gap-1">
            {navItems.map((item) => (
              <NavItem
                key={item.id}  
                icon={item.icon}
                label={item.label}
                href={item.href}
                isActive={location.pathname === item.href}
                onClick={closeSidebarOnMobile}
              />
            ))}
          </div>
        </div>

        <div className="border-t p-3">
          <Button
            variant="ghost"
            className={cn(
              "w-full justify-start gap-3 text-muted-foreground",
              !isSidebarOpen && "justify-center"
            )}
            onClick={handleLogout}
          >
            <LogOut className="h-4 w-4" />
            <span className={cn("transition-opacity duration-200", !isSidebarOpen && "hidden")}>
              Log out
            </span>
          </Button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0 w-full">
        <Navbar onMenuClick={() => setIsSidebarOpen(!isSidebarOpen)} />
        <main className="flex-1 overflow-auto p-4 md:p-6">
          <div className="mx-auto max-w-7xl animate-fade-in">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
