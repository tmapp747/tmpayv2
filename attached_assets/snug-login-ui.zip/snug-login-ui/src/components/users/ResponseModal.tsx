
import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface ResponseModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  response: {
    status: string;
    link: string;
    transactionId: string;
  } | null;
}

export function ResponseModal({ open, onOpenChange, response }: ResponseModalProps) {
  if (!response) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Transaction Response</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          <div className="space-y-4">
            <div>
              <p className="font-semibold">Status:</p>
              <p className="text-green-600">{response.status}</p>
            </div>
            <div>
              <p className="font-semibold">Transaction ID:</p>
              <p>{response.transactionId}</p>
            </div>
            <div>
              <p className="font-semibold">Payment Link:</p>
              <a 
                href={response.link} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline break-all"
              >
                {response.link}
              </a>
            </div>
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button type="button">Close</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
