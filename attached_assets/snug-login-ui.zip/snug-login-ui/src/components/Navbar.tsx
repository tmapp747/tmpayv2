
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { Bell, Menu, Search, User } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

interface NavbarProps extends React.HTMLAttributes<HTMLDivElement> {
  onMenuClick?: () => void;
}

export function Navbar({ onMenuClick, className, ...props }: NavbarProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogout = () => {
    // Clear all auth related session storage
    sessionStorage.removeItem("loggedIn");
    sessionStorage.removeItem("userData");
    sessionStorage.removeItem("data");
    
    // Trigger storage event for App.tsx to detect
    window.dispatchEvent(new Event('storage'));
    
    toast({
      title: "Logged out successfully",
      description: "You have been logged out of your account",
    });
    
    navigate("/login", { replace: true });
  };

  return (
    <div
      className={cn(
        "h-16 px-4 border-b bg-background/95 backdrop-blur-md sticky top-0 z-10 flex items-center justify-between",
        className
      )}
      {...props}
    >
      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          onClick={onMenuClick}
          className="md:flex"
          aria-label="Toggle sidebar"
        >
          <Menu className="h-5 w-5" />
        </Button>
        
        {!isSearchOpen && (
          <div className="hidden md:block">
            <h1 className="text-xl font-semibold">Dashboard</h1>
          </div>
        )}
      </div>
{/* 
      <div className={cn(
        "hidden md:flex items-center transition-all duration-300",
        isSearchOpen ? "w-[300px]" : "w-[200px]"
      )}>
        <div className="relative w-full">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search..."
            className="w-full pl-8 rounded-full border-muted bg-background h-9"
            onFocus={() => setIsSearchOpen(true)}
            onBlur={() => setIsSearchOpen(false)}
          />
        </div>
      </div> */}

      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full"
          onClick={() => {
            toast({
              title: "Notifications",
              description: "You have no new notifications",
            });
          }}
        >
          <Bell className="h-5 w-5" />
        </Button>
        
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full"
          onClick={handleLogout}
        >
          <User className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}
