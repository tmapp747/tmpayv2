
import { cn } from "@/lib/utils";
import { cva, type VariantProps } from "class-variance-authority";
import { ReactNode } from "react";

const statCardVariants = cva(
  "relative p-6 rounded-xl shadow-subtle overflow-hidden animate-enter transition-all duration-300",
  {
    variants: {
      variant: {
        default: "bg-white border border-border/50",
        primary: "bg-primary/10 border border-primary/20",
        secondary: "bg-secondary border border-secondary/50",
        glass: "glass-morphism",
        success: "bg-green-100 border border-green-300",
        error: "bg-red-100 border border-red-300",
        warning: "bg-yellow-100 border border-yellow-300",
        info: "bg-blue-100 border border-blue-300"
      },
      size: {
        default: "h-[140px]",
        sm: "h-[120px]",
        lg: "h-[180px]",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

export interface StatCardProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof statCardVariants> {
  title: string;
  value: string | number;
  icon?: ReactNode;
  trend?: {
    value: number;
    isPositive: boolean;
  };
}

export function StatCard({
  className,
  variant,
  size,
  title,
  value,
  icon,
  trend,
  ...props
}: StatCardProps) {
  return (
    <div
      className={cn(
        statCardVariants({ variant, size }),
        "hover:shadow-glass hover:scale-[1.01] group",
        className
      )}
      {...props}
    >
      <div className="absolute top-4 right-4 text-primary/60 group-hover:text-primary transition-colors duration-300">
        {icon}
      </div>
      <div className="flex flex-col gap-2">
        <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
        <div className="flex items-end gap-2">
          <p className="text-2xl font-semibold">{value}</p>
          {trend && (
            <span
              className={cn(
                "text-xs font-medium pb-1",
                trend.isPositive ? "text-green-500" : "text-red-500"
              )}
            >
              {trend.isPositive ? "↑" : "↓"} {Math.abs(trend.value)}%
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
