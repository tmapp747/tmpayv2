
/**
 * Format a number as Philippine Peso
 * @param amount The amount to format
 * @returns Formatted amount with peso sign and thousand separators
 */
export function formatPesoCurrency(amount: string | number): string {
  // Convert to number if it's a string
  const numericAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
  
  // Check if it's a valid number
  if (isNaN(numericAmount)) return '₱0.00';
  
  // Format with Philippine Peso sign and thousands separators
  return new Intl.NumberFormat('en-PH', {
    style: 'currency',
    currency: 'PHP',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(numericAmount);
}
