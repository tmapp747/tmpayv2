import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Reports from "./pages/Reports";

const queryClient = new QueryClient();

const App = () => {
  const [authChecked, setAuthChecked] = useState(false);
  
  const isLoggedIn = () => {
    const loginToken = sessionStorage.getItem("loggedIn");
    const userData = sessionStorage.getItem("userData");
    const authToken = sessionStorage.getItem("data");
    
    return loginToken === "true" && !!userData && !!authToken;
  };
  
  useEffect(() => {
    const checkAuth = () => {
      setAuthChecked(!authChecked);
    };
    
    window.addEventListener('storage', checkAuth);
    
    checkAuth();
    
    return () => {
      window.removeEventListener('storage', checkAuth);
    };
  }, [authChecked]);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Navigate to={isLoggedIn() ? "/dashboard" : "/login"} replace />} />
            <Route 
              path="/login" 
              element={isLoggedIn() ? <Navigate to="/dashboard" replace /> : <Login />} 
            />
            <Route 
              path="/dashboard" 
              element={!isLoggedIn() ? <Navigate to="/login" replace /> : <Dashboard />} 
            />
            <Route path="/dashboard/main" element={!isLoggedIn() ? <Navigate to="/login" replace /> : <Dashboard />} />
            <Route 
              path="/reports" 
              element={!isLoggedIn() ? <Navigate to="/login" replace /> : <Reports />} 
            />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
